package net.javaguides.springboot.service.impl;

import lombok.AllArgsConstructor;
import net.javaguides.springboot.dto.UserDto;
import net.javaguides.springboot.entity.User;
import net.javaguides.springboot.exception.EmailAlreadyExistsException;
import net.javaguides.springboot.exception.ResponceNotFoundException;
import net.javaguides.springboot.mapper.UserMapper;
import net.javaguides.springboot.repository.UserRepository;
import net.javaguides.springboot.service.UserService;
import org.apache.logging.log4j.util.Strings;
import org.springframework.core.ReactiveAdapter;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import org.springframework.web.client.ResourceAccessException;

import java.util.List;
import java.util.Objects;
import java.util.Optional;import java.util.stream.Collector;
import java.util.stream.Collectors;

@Service
@AllArgsConstructor
public class UserServiceImpl implements UserService {

    private UserRepository userRepository;

    @Override
    public UserDto createUser(UserDto userDto) {
 
    	
    	// This will through exception when email is a
    	Optional<User> optionalUser = userRepository.findByEmail(userDto.getEmail());
    	
    	if(optionalUser.isPresent()) {
    		 throw new EmailAlreadyExistsException("Email is exist");
    	}
    	
    	//Convert UserDto into User JPA Entity
    	User user1= UserMapper.mapToUser(userDto);
         
    	User savedUser = userRepository.save(user1);
         
        //Convert User JPA into UserDto   	   
    	UserDto savedUserDto = UserMapper.mapToUserDto(savedUser);
    	
        return savedUserDto ;
    }

    @Override
    public UserDto getUserById(Long userId) {
        Optional<User> optionalUser = Optional.ofNullable(userRepository.findById(userId).orElseThrow(
        		()-> new ResponceNotFoundException("User", "Id", userId)
        		
        		));
        User user= optionalUser.get();
        return UserMapper.mapToUserDto(user);
    }

    @Override
    public List<UserDto> getAllUsers() {
    	List<User> usersList=userRepository.findAll();
        return usersList.stream().map(UserMapper::mapToUserDto).collect(Collectors.toList());
    }

    @Override
    public UserDto updateUser(UserDto userDto) {
        User existingUser = userRepository.findById(userDto.getId()).orElseThrow(()->new ResponceNotFoundException("user", "Id", userDto.getId()));
        existingUser.setFirstName(userDto.getFirstName());
        existingUser.setLastName(userDto.getLastName());
        existingUser.setEmail(userDto.getEmail());
        User updatedUser = userRepository.save(existingUser);  
        return UserMapper.mapToUserDto(updatedUser);
    }

    @Override
    public void deleteUser(Long userId) {
        User existingUser = userRepository.findById(userId).orElseThrow(()->new ResponceNotFoundException("user", "Id", userId));

        userRepository.deleteById(userId);
    }
}
